#include<stdio.h>
#include"main.h"

int main()
{
	struct endian s1;
	s1.data = 10;
	s1.ch = (char)s1.data;
	check_endianess(&s1);
}

