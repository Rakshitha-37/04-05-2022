struct endian
{
	int data;
	char ch;
};

void check_endianess(struct endian *s1);
