#include<stdio.h>
#include"main.h"

void check_endianess(struct endian *s1)
{
	if(s1->ch == 10)
	{
		printf("System is little endian\n");
	}
	else
	{
		printf("System is big endian\n");
	}
}
